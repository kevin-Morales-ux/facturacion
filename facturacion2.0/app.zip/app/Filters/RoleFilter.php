<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        // 1. Si no hay sesión activa, ir al login
        if (! $session->get('logged_in')) {
            return redirect()->to(site_url('login'));
        }

        $userRole = $session->get('rol');

        // 2. Si se definieron roles en la ruta y el usuario no los cumple:
        if (! empty($arguments) && ! in_array($userRole, $arguments, true)) {

      
            

            // REDIRECCIÓN SEGURA: Redirigir a una ruta garantizada para todos (ej. facturas)
            return redirect()->to(site_url('facturas'))
                ->with('error', 'No tienes permisos para acceder a esta sección.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}