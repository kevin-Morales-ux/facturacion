<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// ==========================================
// 1. RUTAS PÚBLICAS (Sin autenticación)
// ==========================================
$routes->get('login', 'AuthController::index');
$routes->post('login/authenticate', 'AuthController::authenticate');
$routes->get('logout', 'AuthController::logout');

// ==========================================
// 2. RUTAS ACCESIBLES POR AMBOS ROLES
// (Administrador y Encargado)
// ==========================================

// Rutas de Vistas HTML generales y Facturación
$routes->group('', ['filter' => ['auth', 'role:administrador,encargado']], function ($routes) {
    $routes->get('/', 'Home::index');
    $routes->get('dashboard', 'Home::index');
    $routes->get('facturacion', 'Home::index');
    $routes->get('facturas', 'FacturacionController::index');
    $routes->get('facturas/nueva', 'FacturacionController::index');
});

// Endpoints AJAX para Facturación
$routes->group('facturas', ['filter' => ['auth', 'ajax', 'role:administrador,encargado']], function ($routes) {
    $routes->get('getVentas', 'FacturacionController::getVentas');
    $routes->get('buscarClientes', 'FacturacionController::buscarClientes');
    $routes->get('buscarProductos', 'FacturacionController::buscarProductos');
    $routes->post('guardar', 'FacturacionController::guardar');
    $routes->get('obtener/(:num)', 'FacturacionController::obtener/$1');
});

// ==========================================
// 3. RUTAS EXCLUSIVAS PARA ADMINISTRADOR
// ==========================================

// Vistas HTML Módulos de Gestión
$routes->group('', ['filter' => ['auth', 'role:administrador']], function ($routes) {
    $routes->get('categorias', 'CategoriasController::index');
    $routes->get('marcas', 'MarcasController::index');
    $routes->get('clientes', 'ClientesController::index');
    $routes->get('proveedores', 'ProveedoresController::index');
    $routes->get('usuarios', 'UsuariosController::index');
    $routes->get('productos', 'ProductosController::index');
});

// Endpoints AJAX - Categorías
$routes->group('categorias', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getCategorias', 'CategoriasController::getCategorias');
    $routes->post('guardar', 'CategoriasController::guardar');
    $routes->get('obtener/(:num)', 'CategoriasController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'CategoriasController::eliminar/$1');
});

// Endpoints AJAX - Marcas
$routes->group('marcas', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getMarcas', 'MarcasController::getMarcas');
    $routes->post('guardar', 'MarcasController::guardar');
    $routes->get('obtener/(:num)', 'MarcasController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'MarcasController::eliminar/$1');
});

// Endpoints AJAX - Clientes
$routes->group('clientes', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getClientes', 'ClientesController::getClientes');
    $routes->post('guardar', 'ClientesController::guardar');
    $routes->get('obtener/(:num)', 'ClientesController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'ClientesController::eliminar/$1');
});

// Endpoints AJAX - Proveedores
$routes->group('proveedores', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getProveedores', 'ProveedoresController::getProveedores');
    $routes->post('guardar', 'ProveedoresController::guardar');
    $routes->get('obtener/(:num)', 'ProveedoresController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'ProveedoresController::eliminar/$1');
});

// Endpoints AJAX - Usuarios
$routes->group('usuarios', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getUsuarios', 'UsuariosController::getUsuarios');
    $routes->post('guardar', 'UsuariosController::guardar');
    $routes->get('obtener/(:num)', 'UsuariosController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'UsuariosController::eliminar/$1');
});

// Endpoints AJAX - Productos
$routes->group('productos', ['filter' => ['auth', 'ajax', 'role:administrador']], function ($routes) {
    $routes->get('getProductos', 'ProductosController::getProductos');
    $routes->post('guardar', 'ProductosController::guardar');
    $routes->get('obtener/(:num)', 'ProductosController::obtener/$1');
    $routes->delete('eliminar/(:num)', 'ProductosController::eliminar/$1');
});